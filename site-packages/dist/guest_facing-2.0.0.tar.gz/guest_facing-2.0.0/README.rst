Please see the documentation in `OneDrive`
```
GTRIIP - Engineering\Web\HotelTemplate\Guest Facing\
```
