default_app_config = 'guest_facing.core.apps.CoreConfig'
